import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sidebar } from './components/Sidebar';
import { MainWorkspace } from './components/MainWorkspace';
import { AgentPanel } from './components/AgentPanel';
import { EmptyState } from './components/EmptyState';
import { CommandPalette } from './components/CommandPalette';
import { Toaster } from 'sonner';

export type WorkspaceMode = 'plan' | 'code' | 'preview';

export default function App() {
  const [hasStarted, setHasStarted] = useState(false);
  const [mode, setMode] = useState<WorkspaceMode>('plan');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [agentPanelOpen, setAgentPanelOpen] = useState(true);
  const [projectName] = useState('My New Project');
  const [commandPaletteOpen, setCommandPaletteOpen] = useState(false);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Cmd/Ctrl + K to open command palette
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setCommandPaletteOpen(true);
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, []);

  const handleStartProject = (prompt: string) => {
    console.log('Starting project with prompt:', prompt);
    setHasStarted(true);
  };

  return (
    <div className="flex h-screen bg-[#0A0A0A] text-white overflow-hidden">
      <Toaster 
        theme="dark" 
        position="bottom-right"
        toastOptions={{
          style: {
            background: '#111111',
            border: '1px solid #1F1F1F',
            color: '#ffffff',
          },
        }}
      />
      
      <CommandPalette 
        isOpen={commandPaletteOpen} 
        onClose={() => setCommandPaletteOpen(false)} 
      />
      
      <AnimatePresence mode="wait">
        {!hasStarted ? (
          <EmptyState key="empty" onStart={handleStartProject} />
        ) : (
          <motion.div
            key="workspace"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="flex w-full"
          >
            <Sidebar 
              collapsed={sidebarCollapsed} 
              onToggle={() => setSidebarCollapsed(!sidebarCollapsed)}
              activeItem="plan"
            />
            
            <MainWorkspace 
              mode={mode}
              onModeChange={setMode}
              projectName={projectName}
              onOpenAgent={!agentPanelOpen ? () => setAgentPanelOpen(true) : undefined}
            />
            
            <AgentPanel 
              isOpen={agentPanelOpen}
              onToggle={() => setAgentPanelOpen(!agentPanelOpen)}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}