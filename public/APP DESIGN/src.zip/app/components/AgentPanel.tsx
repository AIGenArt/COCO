import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, X, Send, Lightbulb, Zap, Bug } from 'lucide-react';
import { useState } from 'react';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

interface AgentPanelProps {
  isOpen: boolean;
  onToggle: () => void;
}

const suggestions = [
  { icon: Lightbulb, text: 'Improve UI', color: 'text-yellow-400' },
  { icon: Zap, text: 'Add feature', color: 'text-blue-400' },
  { icon: Bug, text: 'Fix bug', color: 'text-red-400' },
];

export function AgentPanel({ isOpen, onToggle }: AgentPanelProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'assistant',
      content: "Hi! I'm COCO. I've generated a plan for your landing page. Would you like me to start building it?",
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState('');

  const handleSend = () => {
    if (!input.trim()) return;

    const newMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: new Date(),
    };

    setMessages([...messages, newMessage]);
    setInput('');

    // Simulate AI response
    setTimeout(() => {
      const aiResponse: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: "I'll help you with that! Let me update the code...",
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, aiResponse]);
    }, 1000);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ width: 0, opacity: 0 }}
          animate={{ width: 380, opacity: 1 }}
          exit={{ width: 0, opacity: 0 }}
          transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
          className="border-l border-[#1F1F1F] bg-[#0A0A0A] flex flex-col overflow-hidden"
        >
          {/* Header */}
          <div className="h-16 border-b border-[#1F1F1F] flex items-center justify-between px-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-white" />
              </div>
              <div>
                <h3 className="text-sm font-semibold">COCO Agent</h3>
                <p className="text-xs text-zinc-500">Always here to help</p>
              </div>
            </div>
            <motion.button
              whileHover={{ scale: 1.1, rotate: 90 }}
              whileTap={{ scale: 0.9 }}
              onClick={onToggle}
              className="p-1.5 text-zinc-400 hover:text-white hover:bg-[#111111] rounded-lg transition-colors"
            >
              <X className="w-4 h-4" />
            </motion.button>
          </div>

          {/* Messages area */}
          <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4">
            {messages.map((message, index) => (
              <motion.div
                key={message.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className={`flex gap-3 ${
                  message.role === 'user' ? 'flex-row-reverse' : 'flex-row'
                }`}
              >
                {message.role === 'assistant' && (
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center flex-shrink-0">
                    <Sparkles className="w-4 h-4 text-white" />
                  </div>
                )}
                <div
                  className={`max-w-[80%] px-4 py-3 rounded-xl ${
                    message.role === 'user'
                      ? 'bg-indigo-600 text-white'
                      : 'bg-[#111111] text-zinc-300 border border-[#1F1F1F]'
                  }`}
                >
                  <p className="text-sm leading-relaxed">{message.content}</p>
                </div>
              </motion.div>
            ))}

            {/* Suggestions */}
            {messages.length === 1 && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="space-y-2"
              >
                <p className="text-xs text-zinc-500 px-2">Quick actions:</p>
                {suggestions.map((suggestion, index) => {
                  const Icon = suggestion.icon;
                  return (
                    <motion.button
                      key={index}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.4 + index * 0.05 }}
                      onClick={() => setInput(suggestion.text)}
                      whileHover={{ x: 4 }}
                      className="w-full flex items-center gap-3 px-3 py-2.5 bg-[#111111] hover:bg-[#1A1A1A] border border-[#1F1F1F] hover:border-zinc-700 rounded-lg transition-all duration-200"
                    >
                      <Icon className={`w-4 h-4 ${suggestion.color}`} />
                      <span className="text-sm text-zinc-300">{suggestion.text}</span>
                    </motion.button>
                  );
                })}
              </motion.div>
            )}
          </div>

          {/* Input area */}
          <div className="p-4 border-t border-[#1F1F1F]">
            <div className="relative">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Ask COCO anything..."
                className="w-full pl-4 pr-12 py-3 bg-[#111111] border border-[#1F1F1F] rounded-lg text-white text-sm placeholder-zinc-500 focus:outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition-all duration-200"
              />
              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={handleSend}
                disabled={!input.trim()}
                className="absolute right-2 top-1/2 -translate-y-1/2 p-2 bg-indigo-600 hover:bg-indigo-500 disabled:bg-zinc-800 disabled:text-zinc-600 text-white rounded-md transition-colors duration-200 disabled:cursor-not-allowed"
              >
                <Send className="w-4 h-4" />
              </motion.button>
            </div>
            <p className="text-xs text-zinc-600 mt-2 text-center">
              Press Enter to send
            </p>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
