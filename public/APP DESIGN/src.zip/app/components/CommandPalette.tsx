import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, Command, File, Folder, Sparkles, Code2 } from 'lucide-react';

interface CommandPaletteProps {
  isOpen: boolean;
  onClose: () => void;
}

const commands = [
  { id: '1', title: 'Generate new plan', icon: Sparkles, category: 'AI' },
  { id: '2', title: 'Open file explorer', icon: Folder, category: 'Navigation' },
  { id: '3', title: 'Create new component', icon: Code2, category: 'Actions' },
  { id: '4', title: 'Search files', icon: File, category: 'Search' },
];

export function CommandPalette({ isOpen, onClose }: CommandPaletteProps) {
  const [search, setSearch] = useState('');

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };

    if (isOpen) {
      document.addEventListener('keydown', handleKeyDown);
      return () => document.removeEventListener('keydown', handleKeyDown);
    }
  }, [isOpen, onClose]);

  const filteredCommands = commands.filter((cmd) =>
    cmd.title.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50"
          />

          {/* Command palette */}
          <div className="fixed inset-0 z-50 flex items-start justify-center pt-[20vh] px-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: -20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: -20 }}
              transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
              className="w-full max-w-2xl bg-[#111111] border border-[#1F1F1F] rounded-xl shadow-2xl overflow-hidden"
            >
              {/* Search input */}
              <div className="flex items-center gap-3 px-4 py-4 border-b border-[#1F1F1F]">
                <Search className="w-5 h-5 text-zinc-500" />
                <input
                  type="text"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search commands..."
                  className="flex-1 bg-transparent text-white placeholder-zinc-500 outline-none"
                  autoFocus
                />
                <div className="flex items-center gap-1 px-2 py-1 bg-[#1A1A1A] rounded text-xs text-zinc-500">
                  <Command className="w-3 h-3" />
                  K
                </div>
              </div>

              {/* Results */}
              <div className="max-h-96 overflow-y-auto p-2">
                {filteredCommands.length === 0 ? (
                  <div className="py-8 text-center text-zinc-500 text-sm">
                    No commands found
                  </div>
                ) : (
                  <div className="space-y-1">
                    {filteredCommands.map((cmd, index) => {
                      const Icon = cmd.icon;
                      return (
                        <motion.button
                          key={cmd.id}
                          initial={{ opacity: 0, x: -10 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: index * 0.03 }}
                          onClick={onClose}
                          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-[#1A1A1A] transition-colors duration-150 group"
                        >
                          <div className="w-8 h-8 rounded-md bg-indigo-600/10 border border-indigo-600/20 flex items-center justify-center flex-shrink-0">
                            <Icon className="w-4 h-4 text-indigo-400" />
                          </div>
                          <div className="flex-1 text-left">
                            <div className="text-sm text-white">{cmd.title}</div>
                            <div className="text-xs text-zinc-500">{cmd.category}</div>
                          </div>
                        </motion.button>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Footer */}
              <div className="px-4 py-3 border-t border-[#1F1F1F] flex items-center justify-between text-xs text-zinc-500">
                <div>Type to search...</div>
                <div className="flex items-center gap-2">
                  <kbd className="px-2 py-1 bg-[#1A1A1A] rounded">↑↓</kbd>
                  <span>to navigate</span>
                  <kbd className="px-2 py-1 bg-[#1A1A1A] rounded">↵</kbd>
                  <span>to select</span>
                </div>
              </div>
            </motion.div>
          </div>
        </>
      )}
    </AnimatePresence>
  );
}
