import { motion } from 'motion/react';
import { WorkspaceMode } from '../App';
import { ListTodo, Code2, Eye } from 'lucide-react';

interface ModeSelectorProps {
  mode: WorkspaceMode;
  onChange: (mode: WorkspaceMode) => void;
}

const modes = [
  { id: 'plan' as const, label: 'Plan', icon: ListTodo },
  { id: 'code' as const, label: 'Code', icon: Code2 },
  { id: 'preview' as const, label: 'Preview', icon: Eye },
];

export function ModeSelector({ mode, onChange }: ModeSelectorProps) {
  return (
    <div className="inline-flex items-center gap-1 p-1 bg-[#111111] rounded-lg border border-[#1F1F1F]">
      {modes.map((m) => {
        const Icon = m.icon;
        const isActive = mode === m.id;
        
        return (
          <button
            key={m.id}
            onClick={() => onChange(m.id)}
            className="relative px-4 py-2 rounded-md text-sm font-medium transition-colors duration-200"
          >
            {isActive && (
              <motion.div
                layoutId="activeMode"
                className="absolute inset-0 bg-indigo-600 rounded-md"
                transition={{ type: 'spring', bounce: 0.2, duration: 0.6 }}
              />
            )}
            <span className={`relative z-10 flex items-center gap-2 ${
              isActive ? 'text-white' : 'text-zinc-400'
            }`}>
              <Icon className="w-4 h-4" />
              {m.label}
            </span>
          </button>
        );
      })}
    </div>
  );
}
