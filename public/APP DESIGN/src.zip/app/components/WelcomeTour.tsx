import { motion } from 'motion/react';
import { X, Sparkles, Command, Eye, Code2, ListTodo } from 'lucide-react';

interface WelcomeTourProps {
  onClose: () => void;
}

const shortcuts = [
  { key: '⌘K', description: 'Open command palette', icon: Command },
  { key: 'Tab', description: 'Switch between views', icon: Eye },
  { key: '⌘/', description: 'Toggle AI panel', icon: Sparkles },
];

export function WelcomeTour({ onClose }: WelcomeTourProps) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
        className="bg-[#111111] border border-[#1F1F1F] rounded-xl max-w-2xl w-full p-8 shadow-2xl"
      >
        {/* Header */}
        <div className="flex items-start justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center">
              <Sparkles className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-semibold">Welcome to COCO</h2>
              <p className="text-zinc-400 text-sm">Your AI-powered development workspace</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-zinc-400 hover:text-white hover:bg-[#1A1A1A] rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Features */}
        <div className="space-y-6 mb-8">
          <div>
            <h3 className="text-lg font-semibold mb-3">Flow-based workflow</h3>
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-2 px-3 py-2 bg-[#1A1A1A] rounded-lg border border-[#1F1F1F]">
                <ListTodo className="w-4 h-4 text-indigo-400" />
                <span className="text-sm text-zinc-300">Plan</span>
              </div>
              <span className="text-zinc-600">→</span>
              <div className="flex items-center gap-2 px-3 py-2 bg-[#1A1A1A] rounded-lg border border-[#1F1F1F]">
                <Code2 className="w-4 h-4 text-green-400" />
                <span className="text-sm text-zinc-300">Code</span>
              </div>
              <span className="text-zinc-600">→</span>
              <div className="flex items-center gap-2 px-3 py-2 bg-[#1A1A1A] rounded-lg border border-[#1F1F1F]">
                <Eye className="w-4 h-4 text-purple-400" />
                <span className="text-sm text-zinc-300">Preview</span>
              </div>
              <span className="text-zinc-600">→</span>
              <span className="text-sm text-zinc-400">Iterate</span>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-3">Keyboard shortcuts</h3>
            <div className="space-y-2">
              {shortcuts.map((shortcut, index) => {
                const Icon = shortcut.icon;
                return (
                  <div
                    key={index}
                    className="flex items-center justify-between px-4 py-2 bg-[#1A1A1A] rounded-lg"
                  >
                    <div className="flex items-center gap-3">
                      <Icon className="w-4 h-4 text-zinc-500" />
                      <span className="text-sm text-zinc-300">{shortcut.description}</span>
                    </div>
                    <kbd className="px-2 py-1 bg-[#0A0A0A] border border-[#1F1F1F] rounded text-xs text-zinc-500">
                      {shortcut.key}
                    </kbd>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* CTA */}
        <button
          onClick={onClose}
          className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg font-medium transition-colors"
        >
          Get started
        </button>
      </motion.div>
    </div>
  );
}
