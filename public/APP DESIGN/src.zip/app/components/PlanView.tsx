import { motion } from 'motion/react';
import { CheckCircle2, Circle, ChevronRight, Sparkles, Copy, Play } from 'lucide-react';
import { useState } from 'react';
import { toast } from 'sonner';

interface TaskItem {
  id: string;
  title: string;
  completed: boolean;
}

interface PlanSection {
  id: string;
  title: string;
  tasks: TaskItem[];
}

const mockPlan: PlanSection[] = [
  {
    id: '1',
    title: 'Setup & Structure',
    tasks: [
      { id: '1-1', title: 'Create project structure with React and TypeScript', completed: true },
      { id: '1-2', title: 'Setup Tailwind CSS for styling', completed: true },
      { id: '1-3', title: 'Configure routing with React Router', completed: false },
    ],
  },
  {
    id: '2',
    title: 'Core Components',
    tasks: [
      { id: '2-1', title: 'Build responsive navigation bar', completed: false },
      { id: '2-2', title: 'Create hero section with CTA', completed: false },
      { id: '2-3', title: 'Design pricing cards component', completed: false },
      { id: '2-4', title: 'Add feature showcase section', completed: false },
    ],
  },
  {
    id: '3',
    title: 'Styling & Polish',
    tasks: [
      { id: '3-1', title: 'Add smooth scroll animations', completed: false },
      { id: '3-2', title: 'Implement dark mode toggle', completed: false },
      { id: '3-3', title: 'Optimize for mobile responsiveness', completed: false },
    ],
  },
];

export function PlanView() {
  const [sections, setSections] = useState(mockPlan);

  const toggleTask = (sectionId: string, taskId: string) => {
    setSections(sections.map(section => {
      if (section.id === sectionId) {
        return {
          ...section,
          tasks: section.tasks.map(task =>
            task.id === taskId ? { ...task, completed: !task.completed } : task
          ),
        };
      }
      return section;
    }));
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.3 }}
      className="h-full overflow-y-auto"
    >
      <div className="max-w-4xl mx-auto py-8 px-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-8"
        >
          <div className="flex items-center gap-2 mb-3">
            <Sparkles className="w-5 h-5 text-indigo-400" />
            <span className="text-sm font-medium text-indigo-400">AI Generated Plan</span>
          </div>
          <h1 className="text-3xl font-semibold mb-2">Landing Page with Pricing</h1>
          <p className="text-zinc-400">
            Here's a structured plan to build your landing page. Check off tasks as you complete them.
          </p>
        </motion.div>

        {/* Plan sections */}
        <div className="space-y-6">
          {sections.map((section, sectionIndex) => (
            <motion.div
              key={section.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 + sectionIndex * 0.1 }}
              className="bg-[#111111] border border-[#1F1F1F] rounded-xl p-6"
            >
              {/* Section header */}
              <div className="flex items-center gap-3 mb-4">
                <div className="w-8 h-8 rounded-lg bg-indigo-600/10 border border-indigo-600/20 flex items-center justify-center">
                  <span className="text-sm font-semibold text-indigo-400">
                    {sectionIndex + 1}
                  </span>
                </div>
                <h2 className="text-xl font-semibold">{section.title}</h2>
                <div className="ml-auto text-sm text-zinc-500">
                  {section.tasks.filter(t => t.completed).length} / {section.tasks.length}
                </div>
              </div>

              {/* Tasks */}
              <div className="space-y-2">
                {section.tasks.map((task, taskIndex) => (
                  <motion.button
                    key={task.id}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.3 + sectionIndex * 0.1 + taskIndex * 0.05 }}
                    onClick={() => toggleTask(section.id, task.id)}
                    className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-[#1A1A1A] transition-colors duration-200 group"
                  >
                    {task.completed ? (
                      <CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0" />
                    ) : (
                      <Circle className="w-5 h-5 text-zinc-600 group-hover:text-zinc-500 flex-shrink-0" />
                    )}
                    <span
                      className={`text-left flex-1 ${
                        task.completed
                          ? 'text-zinc-500 line-through'
                          : 'text-zinc-300'
                      }`}
                    >
                      {task.title}
                    </span>
                    <ChevronRight className="w-4 h-4 text-zinc-600 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </motion.button>
                ))}
              </div>
            </motion.div>
          ))}
        </div>

        {/* Bottom input */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="mt-8 mb-8"
        >
          <div className="relative">
            <input
              type="text"
              placeholder="Ask COCO to modify the plan..."
              className="w-full px-4 py-3 bg-[#111111] border border-[#1F1F1F] rounded-xl text-white placeholder-zinc-500 focus:outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition-all duration-200"
            />
            <button className="absolute right-2 top-1/2 -translate-y-1/2 px-4 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-sm rounded-lg font-medium transition-colors duration-200">
              Update
            </button>
          </div>
        </motion.div>
      </div>
    </motion.div>
  );
}