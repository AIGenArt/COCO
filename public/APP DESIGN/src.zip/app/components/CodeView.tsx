import { motion } from 'motion/react';
import { useState } from 'react';
import { ChevronRight, ChevronDown, FileCode, Folder, FolderOpen } from 'lucide-react';

interface FileNode {
  id: string;
  name: string;
  type: 'file' | 'folder';
  children?: FileNode[];
}

const mockFileTree: FileNode[] = [
  {
    id: '1',
    name: 'src',
    type: 'folder',
    children: [
      {
        id: '1-1',
        name: 'components',
        type: 'folder',
        children: [
          { id: '1-1-1', name: 'Header.tsx', type: 'file' },
          { id: '1-1-2', name: 'Hero.tsx', type: 'file' },
          { id: '1-1-3', name: 'Pricing.tsx', type: 'file' },
        ],
      },
      { id: '1-2', name: 'App.tsx', type: 'file' },
      { id: '1-3', name: 'index.tsx', type: 'file' },
    ],
  },
  {
    id: '2',
    name: 'public',
    type: 'folder',
    children: [
      { id: '2-1', name: 'index.html', type: 'file' },
    ],
  },
  { id: '3', name: 'package.json', type: 'file' },
  { id: '4', name: 'tsconfig.json', type: 'file' },
];

const mockCode = `import { motion } from 'motion/react';

export function Hero() {
  return (
    <section className="min-h-screen flex items-center justify-center">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="max-w-4xl mx-auto text-center px-6"
      >
        <h1 className="text-6xl font-bold mb-6">
          Build amazing products
        </h1>
        <p className="text-xl text-zinc-400 mb-8">
          The fastest way to ship your next project
        </p>
        <button className="px-8 py-4 bg-indigo-600 rounded-lg">
          Get Started
        </button>
      </motion.div>
    </section>
  );
}`;

function FileTreeItem({ node, level = 0 }: { node: FileNode; level?: number }) {
  const [isOpen, setIsOpen] = useState(true);

  if (node.type === 'file') {
    return (
      <motion.button
        whileHover={{ x: 2 }}
        className="flex items-center gap-2 px-3 py-1.5 w-full text-left text-sm text-zinc-400 hover:text-white hover:bg-[#1A1A1A] rounded transition-colors duration-150"
        style={{ paddingLeft: `${level * 12 + 12}px` }}
      >
        <FileCode className="w-4 h-4 flex-shrink-0" />
        <span>{node.name}</span>
      </motion.button>
    );
  }

  return (
    <div>
      <motion.button
        whileHover={{ x: 2 }}
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 px-3 py-1.5 w-full text-left text-sm text-zinc-400 hover:text-white hover:bg-[#1A1A1A] rounded transition-colors duration-150"
        style={{ paddingLeft: `${level * 12 + 12}px` }}
      >
        {isOpen ? (
          <>
            <ChevronDown className="w-4 h-4 flex-shrink-0" />
            <FolderOpen className="w-4 h-4 flex-shrink-0" />
          </>
        ) : (
          <>
            <ChevronRight className="w-4 h-4 flex-shrink-0" />
            <Folder className="w-4 h-4 flex-shrink-0" />
          </>
        )}
        <span>{node.name}</span>
      </motion.button>
      {isOpen && node.children && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          exit={{ opacity: 0, height: 0 }}
        >
          {node.children.map((child) => (
            <FileTreeItem key={child.id} node={child} level={level + 1} />
          ))}
        </motion.div>
      )}
    </div>
  );
}

export function CodeView() {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.3 }}
      className="flex h-full"
    >
      {/* File tree */}
      <div className="w-64 border-r border-[#1F1F1F] bg-[#0A0A0A] overflow-y-auto">
        <div className="p-3 border-b border-[#1F1F1F]">
          <h3 className="text-sm font-semibold text-zinc-400">Files</h3>
        </div>
        <div className="py-2">
          {mockFileTree.map((node) => (
            <FileTreeItem key={node.id} node={node} />
          ))}
        </div>
      </div>

      {/* Code editor */}
      <div className="flex-1 flex flex-col bg-[#0A0A0A]">
        {/* Tab bar */}
        <div className="h-10 border-b border-[#1F1F1F] flex items-center px-4 gap-2">
          <div className="px-3 py-1 bg-[#111111] rounded text-sm text-zinc-300 border border-[#1F1F1F]">
            Hero.tsx
          </div>
        </div>

        {/* Editor content */}
        <div className="flex-1 overflow-auto">
          <div className="p-6">
            <pre className="text-sm leading-relaxed">
              <code className="text-zinc-300 font-mono">
                {mockCode.split('\n').map((line, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.02 }}
                    className="hover:bg-[#111111] px-2 -mx-2 rounded"
                  >
                    <span className="inline-block w-8 text-zinc-600 select-none">
                      {i + 1}
                    </span>
                    <span dangerouslySetInnerHTML={{ 
                      __html: line
                        .replace(/import|export|function|return|const|from/g, '<span class="text-purple-400">$&</span>')
                        .replace(/className|initial|animate|transition|duration/g, '<span class="text-blue-400">$&</span>')
                        .replace(/"[^"]*"/g, '<span class="text-green-400">$&</span>')
                        .replace(/\/\/.*/g, '<span class="text-zinc-600">$&</span>')
                    }} />
                  </motion.div>
                ))}
              </code>
            </pre>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
