import { motion } from 'motion/react';
import { RefreshCw, ExternalLink, Smartphone, Monitor } from 'lucide-react';
import { useState } from 'react';

type ViewportSize = 'desktop' | 'mobile';

export function PreviewView() {
  const [viewportSize, setViewportSize] = useState<ViewportSize>('desktop');

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.3 }}
      className="h-full flex flex-col bg-[#0A0A0A]"
    >
      {/* Preview controls */}
      <div className="h-12 border-b border-[#1F1F1F] flex items-center justify-between px-4">
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 p-1 bg-[#111111] rounded-lg border border-[#1F1F1F]">
            <button
              onClick={() => setViewportSize('desktop')}
              className={`p-1.5 rounded transition-colors ${
                viewportSize === 'desktop'
                  ? 'bg-indigo-600 text-white'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              <Monitor className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewportSize('mobile')}
              className={`p-1.5 rounded transition-colors ${
                viewportSize === 'mobile'
                  ? 'bg-indigo-600 text-white'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              <Smartphone className="w-4 h-4" />
            </button>
          </div>

          <div className="px-3 py-1.5 bg-[#111111] border border-[#1F1F1F] rounded-lg text-sm text-zinc-400 font-mono">
            localhost:3000
          </div>
        </div>

        <div className="flex items-center gap-2">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="p-2 text-zinc-400 hover:text-white hover:bg-[#111111] rounded-lg transition-colors"
          >
            <RefreshCw className="w-4 h-4" />
          </motion.button>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="p-2 text-zinc-400 hover:text-white hover:bg-[#111111] rounded-lg transition-colors"
          >
            <ExternalLink className="w-4 h-4" />
          </motion.button>
        </div>
      </div>

      {/* Preview frame */}
      <div className="flex-1 flex items-center justify-center p-8 bg-zinc-950">
        <motion.div
          key={viewportSize}
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.3 }}
          className={`bg-white rounded-xl shadow-2xl overflow-hidden ${
            viewportSize === 'desktop' ? 'w-full h-full' : 'w-96 h-[calc(100%-4rem)]'
          }`}
        >
          {/* Mock preview content */}
          <div className="w-full h-full flex flex-col">
            {/* Mock header */}
            <div className="bg-gradient-to-r from-indigo-600 to-purple-600 px-6 py-4 flex items-center justify-between">
              <div className="text-white font-semibold">MyApp</div>
              <div className="flex gap-4 text-sm text-white/80">
                <button>Features</button>
                <button>Pricing</button>
                <button>About</button>
              </div>
            </div>

            {/* Mock content */}
            <div className="flex-1 overflow-auto">
              {/* Hero section */}
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="min-h-[400px] flex items-center justify-center bg-gradient-to-b from-indigo-50 to-white px-6"
              >
                <div className="text-center max-w-2xl">
                  <motion.h1 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.3 }}
                    className="text-5xl font-bold text-gray-900 mb-4"
                  >
                    Build amazing products
                  </motion.h1>
                  <motion.p 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.4 }}
                    className="text-xl text-gray-600 mb-8"
                  >
                    The fastest way to ship your next project
                  </motion.p>
                  <motion.button
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: 0.5 }}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="px-8 py-4 bg-indigo-600 text-white rounded-lg font-semibold shadow-lg hover:bg-indigo-700 transition-colors"
                  >
                    Get Started
                  </motion.button>
                </div>
              </motion.div>

              {/* Features section */}
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.6 }}
                className="px-6 py-16 bg-white"
              >
                <div className="max-w-6xl mx-auto">
                  <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
                    Key Features
                  </h2>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    {[1, 2, 3].map((i) => (
                      <motion.div
                        key={i}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.7 + i * 0.1 }}
                        className="p-6 bg-gray-50 rounded-xl"
                      >
                        <div className="w-12 h-12 bg-indigo-100 rounded-lg mb-4 flex items-center justify-center">
                          <div className="w-6 h-6 bg-indigo-600 rounded" />
                        </div>
                        <h3 className="text-xl font-semibold text-gray-900 mb-2">
                          Feature {i}
                        </h3>
                        <p className="text-gray-600">
                          Amazing feature description that makes your product stand out.
                        </p>
                      </motion.div>
                    ))}
                  </div>
                </div>
              </motion.div>

              {/* Pricing section */}
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.9 }}
                className="px-6 py-16 bg-gray-50"
              >
                <div className="max-w-6xl mx-auto">
                  <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
                    Simple Pricing
                  </h2>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {['Starter', 'Pro', 'Enterprise'].map((plan, i) => (
                      <motion.div
                        key={plan}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 1 + i * 0.1 }}
                        className={`p-8 bg-white rounded-xl border-2 ${
                          i === 1 ? 'border-indigo-600 shadow-lg scale-105' : 'border-gray-200'
                        }`}
                      >
                        <h3 className="text-xl font-semibold text-gray-900 mb-2">
                          {plan}
                        </h3>
                        <div className="mb-6">
                          <span className="text-4xl font-bold text-gray-900">
                            ${(i + 1) * 10}
                          </span>
                          <span className="text-gray-600">/month</span>
                        </div>
                        <button
                          className={`w-full py-3 rounded-lg font-semibold transition-colors ${
                            i === 1
                              ? 'bg-indigo-600 text-white hover:bg-indigo-700'
                              : 'bg-gray-100 text-gray-900 hover:bg-gray-200'
                          }`}
                        >
                          Get Started
                        </button>
                      </motion.div>
                    ))}
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </motion.div>
      </div>
    </motion.div>
  );
}
