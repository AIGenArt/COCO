import { motion } from 'motion/react';
import { Wifi, Cloud, Zap } from 'lucide-react';

export function StatusBar() {
  return (
    <motion.div
      initial={{ y: 20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ delay: 0.5 }}
      className="h-7 border-t border-[#1F1F1F] bg-[#0A0A0A] flex items-center justify-between px-4 text-xs text-zinc-500"
    >
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-1.5">
          <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse" />
          <span>Connected</span>
        </div>
        
        <div className="flex items-center gap-1.5">
          <Zap className="w-3 h-3" />
          <span>Ready</span>
        </div>
      </div>

      <div className="flex items-center gap-4">
        <div className="flex items-center gap-1.5">
          <Cloud className="w-3 h-3" />
          <span>Auto-save enabled</span>
        </div>
        
        <div className="flex items-center gap-1.5">
          <Wifi className="w-3 h-3" />
          <span>Online</span>
        </div>
      </div>
    </motion.div>
  );
}
