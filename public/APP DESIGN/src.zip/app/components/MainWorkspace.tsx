import { motion } from 'motion/react';
import { WorkspaceMode } from '../App';
import { ModeSelector } from './ModeSelector';
import { PlanView } from './PlanView';
import { CodeView } from './CodeView';
import { PreviewView } from './PreviewView';
import { StatusBar } from './StatusBar';
import { Sparkles, Command } from 'lucide-react';

interface MainWorkspaceProps {
  mode: WorkspaceMode;
  onModeChange: (mode: WorkspaceMode) => void;
  projectName: string;
  onOpenAgent?: () => void;
}

export function MainWorkspace({ mode, onModeChange, projectName, onOpenAgent }: MainWorkspaceProps) {
  return (
    <div className="flex-1 flex flex-col bg-[#0A0A0A] overflow-hidden">
      {/* Top bar */}
      <div className="h-16 border-b border-[#1F1F1F] flex items-center justify-between px-6">
        <div className="flex items-center gap-3">
          <h2 className="text-sm font-medium text-zinc-400">{projectName}</h2>
          
          {/* Command palette hint */}
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="hidden md:flex items-center gap-2 px-3 py-1.5 bg-[#111111] border border-[#1F1F1F] rounded-lg text-xs text-zinc-500 hover:text-zinc-300 hover:border-zinc-700 transition-colors"
          >
            <Command className="w-3 h-3" />
            <span>K</span>
          </motion.button>
        </div>

        <ModeSelector mode={mode} onChange={onModeChange} />

        <div className="flex items-center gap-2">
          {onOpenAgent && (
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={onOpenAgent}
              className="flex items-center gap-2 px-3 py-1.5 bg-indigo-600/10 border border-indigo-600/20 rounded-lg text-sm text-indigo-400 hover:bg-indigo-600/20 transition-colors"
            >
              <Sparkles className="w-4 h-4" />
              <span className="hidden sm:inline">Ask COCO</span>
            </motion.button>
          )}
        </div>
      </div>

      {/* Content area */}
      <div className="flex-1 relative overflow-hidden">
        {mode === 'plan' && <PlanView key="plan" />}
        {mode === 'code' && <CodeView key="code" />}
        {mode === 'preview' && <PreviewView key="preview" />}
      </div>

      {/* Status bar */}
      <StatusBar />
    </div>
  );
}