Design a modern, minimal, AI-first coding workspace UI called "COCO".

The product is a browser-based development environment that combines:
- planning (AI-generated plans)
- coding (editor)
- preview (live output)
- agent (AI assistant)

The design should feel like a mix of:
- Henosia (AI-first layout)
- Linear (clean and minimal)
- Vercel (premium and structured)
- VS Code (but simplified)

---

CORE DESIGN PRINCIPLES

- Dark mode first
- Minimal UI, no visual noise
- Focus on content and flow
- Smooth transitions and subtle interactions
- AI is central, not secondary
- Everything should feel fast, calm, and intentional

---

LAYOUT STRUCTURE

Create a 3-column layout:

1. LEFT SIDEBAR (navigation)
2. MAIN WORKSPACE (dynamic content)
3. RIGHT PANEL (AI / Agent chat)

---

SIDEBAR DESIGN

- Very minimal
- Width: 64px collapsed, 200px expanded
- Dark background (#0A0A0A)
- Icons + labels (labels fade in on expand)

Content:
- COCO logo
- Dashboard
- Workspaces
- Plan
- Agent
- Files
- Divider
- GitHub
- Settings

Active item should have a subtle accent highlight.

---

MAIN WORKSPACE

Top center:
Create a segmented control (pill style):

[ Plan ] [ Code ] [ Preview ]

- Smooth animated transitions
- Active state uses soft glow or underline

---

MODE 1: PLAN VIEW

- Centered layout
- Large readable text
- AI-generated structured plan
- Sections with steps / checklists

Bottom input field:
"Ask COCO..."

- This is the primary interaction

---

MODE 2: CODE VIEW

Layout:
- Left: file tree
- Center: code editor

Editor:
- Minimal
- Dark background
- Monospace font (JetBrains Mono)

File tree:
- Collapsible
- Clean hierarchy

Optional:
- subtle right panel for logs or agent suggestions

---

MODE 3: PREVIEW VIEW

- Full-width preview canvas
- Looks like a live web app
- Minimal controls
- Clean and distraction-free

---

RIGHT PANEL (AGENT)

- Chat-style interface
- Fixed panel on the right
- Can collapse/expand

Content:
- Title: "COCO"
- Prompt:
  "What do you want to build?"

Input at bottom:
- Large input field

Chat above:
- Messages
- Suggestions:
  - Build feature
  - Fix bug
  - Improve UI

Each response should allow:
- Apply
- Edit
- Explain

---

FIRST-TIME USER STATE

Empty workspace screen:

Centered:

"What do you want to build?"

Large input field below.

This is the key "magic moment".

---

VISUAL STYLE

Colors:
- Background: #0A0A0A
- Surface: #111111
- Border: #1F1F1F
- Accent: #6366F1 (indigo)
- Hover: #818CF8
- Text primary: #FFFFFF
- Text secondary: #A1A1AA

---

TYPOGRAPHY

- Primary: Inter or Geist
- Code: JetBrains Mono
- Large headings, generous spacing

---

COMPONENT STYLE

- Rounded corners (medium radius)
- Soft shadows
- No heavy borders
- Subtle hover states
- Smooth transitions

---

SCREENS TO DESIGN

1. Login screen (minimal, clean)
2. Empty workspace (AI prompt focus)
3. Plan view
4. Code view
5. Preview view
6. Agent panel open
7. Sidebar expanded + collapsed

---

GOAL

The UI should feel like:
"I describe what I want → the system helps me build it instantly"

Not like a traditional IDE or dashboard.