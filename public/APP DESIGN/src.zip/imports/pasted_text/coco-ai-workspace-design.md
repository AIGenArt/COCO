Design a modern AI-powered coding workspace UI called “COCO”, inspired by Henosia.

## Overall Layout

Create a full-screen dark SaaS interface with a 3-column layout:

1. Left Sidebar (navigation)
2. Main Workspace (center)
3. AI Agent Panel (right)

The interface must feel like:

* VS Code + ChatGPT + Vercel combined
* Minimal, clean, professional
* Built for developers and builders

---

## Sidebar (Left - 72px collapsed / 220px expanded)

Top:

* COCO logo (simple dot or minimal icon)

Navigation items:

* Dashboard
* Workspaces
* Plan
* Agent
* Files

Bottom:

* GitHub
* Settings

Style:

* Dark background (#0B0F14)
* Icons only when collapsed
* Smooth hover states
* Active item highlighted with subtle glow

---

## Main Workspace (Center)

Top bar:

* Tabs: [Plan] [Code] [Preview]
* Workspace name (center top)
* Controls: refresh, run, deploy

### PLAN VIEW

* Structured task breakdown (AI-generated)
* Sections with headings and bullet points
* Editable inline
* Clean typography, lots of spacing

### CODE VIEW

* Full IDE layout
* Left: file tree
* Center: code editor (dark theme, syntax highlighting)
* Bottom: terminal panel (optional)

### PREVIEW VIEW

* Live rendered app
* Responsive container (browser-like frame)
* Top bar: URL + refresh

---

## AI AGENT PANEL (Right side)

Top:

* "COCO Agent"

Content:

* Chat history (scrollable)
* Each message styled as modern chat bubbles
* Suggestions:

  * Improve UI
  * Add feature
  * Fix bug

Bottom:

* Sticky input field
* Placeholder: "What do you want to build?"

---

## EMPTY STATE (First screen)

Center screen:

* Large heading:
  “What do you want to build?”

* Input box:
  “Build a landing page with pricing section…”

* CTA button:
  “Generate plan”

Minimal, calm, focused.

---

## Dashboard Screen

Top:

* Prompt input field

Center:

* Grid of project cards

  * Title
  * Last edited
  * Preview thumbnail

Top right:

* User avatar

---

## Visual Style

Theme:

* Dark mode first

Colors:

* Background: #0B0F14
* Surface: #111827
* Accent: #3B82F6 (blue)
* Success: #10B981

Typography:

* Inter / SF Pro
* Clean, readable

Spacing:

* 8px grid system

Components:

* Rounded cards (8–12px radius)
* Soft shadows
* Subtle borders (#1F2937)

---

## UX Principles

* Everything happens in ONE screen
* No page reloads
* Fast transitions
* AI + Code + Preview tightly integrated

---

## Interaction Flow

User types prompt →
AI generates plan →
User edits plan →
Code is generated →
Preview updates live →
User iterates with AI

---

## Feel

* Like a premium developer tool
* Fast, powerful, intelligent
* Not cluttered
* Feels like “co-building with AI”
